from __future__ import print_function

import time
import ex2_getVoice2Text as gv2t
import ex1_kwstest as kws
import ex4_getText2VoiceStream as tts
import RPi.GPIO as gp
import MicrophoneStream as MS

from threading import Thread

from firebase import firebase
import py_serial as ps
import py_youtube as py

import grpc
import user_auth as UA
import gigagenieRPC_pb2
import gigagenieRPC_pb2_grpc
import os

import argparse,pafy,ffmpeg,pyaudio

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


HOST = 'gate.gigagenie.ai'
PORT = 4080

DEVELOPER_KEY = 'AIzaSyBE1ufqI-YffblRiPcOa8IZGO0HtchgpCM'
YOUTUBE_API_SERVICE_NAME='youtube'
YOUTUBE_API_VERSION='v3'

gp.cleanup()

gp.setmode(gp.BOARD)
gp.setwarnings(False)
gp.setup(29, gp.IN, pull_up_down=gp.PUD_UP)
gp.setup(31,gp.OUT)
btn_status = False

play_flag = 0




def callback(channel):
    print("falling edge detected from pin {}".format(channel))
    global btn_status
    btn_status = True
    print(btn_status)
    global play_flag
    play_flag = 1

gp.add_event_detect(29,gp.FALLING, callback=callback, bouncetime=10)

fb = firebase.FirebaseApplication("https://getdata-from-rapa-default-rtdb.firebaseio.com/", None)



def queryByText(text):

	channel = grpc.secure_channel('{}:{}'.format(HOST, PORT), UA.getCredentials())
	stub = gigagenieRPC_pb2_grpc.GigagenieStub(channel)

	message = gigagenieRPC_pb2.reqQueryText()
	message.queryText = text
	message.userSession = "1234"
	message.deviceId = "yourdevice"
		
	response = stub.queryByText(message)

	print ("\n\nresultCd: %d" % (response.resultCd))
	if response.resultCd == 200:
		print ("\n\n\n질의한 내용: %s" % (response.uword))
		#dssAction = response.action
		for a in response.action:
			response = a.mesg
		parsing_resp = response.replace('<![CDATA[', '')
		parsing_resp = parsing_resp.replace(']]>', '')
		print("\n\n질의에 대한 답변: " + parsing_resp + '\n\n\n')
		return parsing_resp
		#return response.url
                #tts.getText2VoiceStream(parsing_resp, "result_TTS.wav")
                #MS.play_file("result_TTS.wav")
	else:
		print ("Fail: %d" % (response.resultCd))


def ledControl(result):
    text = result
    car_name = fb.get('cars_func/car_name',None)
    if text.find("침실 켜줘") >= 0 :
        print("침실불이 켜집니다.")
        ps.led_on('liv',car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'liv':'on'})
        return ("침실불이 켜집니다.")
    elif text.find("침실 꺼") >= 0:
        print("침실불이 꺼집니다.")
        ps.led_off('liv',car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'liv':'off'})
        return ("침실불이 꺼집니다.")
    elif text.find("화장실 켜줘") >= 0:
        print("화장실불이 켜집니다.")
        ps.led_off('bath',car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'bath':'on'})
        return ("화장실불이 켜집니다.")
    elif text.find("화장실 꺼") >= 0:
        print("화장실불이 꺼집니다.")
        ps.led_off('bath',car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'bath':'off'})
        return ("화장실불이 꺼집니다.")
    elif text.find("주방 켜줘") >= 0:
        print("주방불이 켜집니다.")
        ps.led_off('kit',car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'kit':'on'})
        return ("주방불이 켜집니다.")
    elif text.find("주방 꺼") >= 0:
        print("주방불이 꺼집니다.")
        ps.led_off('kit',car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'kit':'off'})
        return ("주방불이 꺼집니다.")
    elif text.find("외부 등 켜줘") >= 0:
        print("외부등이 켜집니다.")
        ps.led_on('outdoor',car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'outdoor':'on'})
        return ("외부등이 켜집니다.")
    elif text.find("외부 등 꺼") >= 0:
        print("외부등이 꺼집니다.")
        ps.led_off('outdoor',car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'outdoor':'off'})
        return ("외부등이 꺼집니다.")
    elif text.find("에어컨 켜줘") >= 0:
        print("에어컨이 켜집니다.")
        ps.air_on(car_name)
        fb.patch('cars_func/{}/power'.format(car_name),{'air':'on'})
        return ("에어컨이 켜집니다.")
    elif text.find("에어컨 꺼") >= 0:
        print("에어컨이 꺼집니다.")
        ps.air_off(car_name)
        fb.patch('cars_func/{}/power'.format(car_name),{'air':'off'})
        return ("에어컨이 꺼집니다.")
    elif text.find("SUNROOF 열어줘") >= 0 or text.find("sunroof 열어줘") >= 0:
        print("창문이 열립니다.")
        ps.window_on(car_name)
        fb.patch('cars_func/{}/power'.format(car_name),{'sunroof':'on'})
        return ("창문이 열립니다")
    elif text.find("SUNROOF 닫아") >= 0 or text.find("sunroof 닫아") >= 0:
        print("창문이 닫힙니다")
        ps.window_off(car_name)
        fb.patch('cars_func/{}/power'.format(car_name),{'sunroof':'off'})
        return ("창문이 닫힙니다")
    elif text.find("모두 꺼") >= 0:
        print("모든 전원이 꺼집니다.")
        ps.led_off('liv',car_name)
        ps.led_off('bath',car_name)
        ps.led_off('kit',car_name)
        ps.led_off('outdoor',car_name)
        ps.air_off(car_name)
        ps.window_off(car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'liv':'off','bath':'off','kit':'off','outdoor':'off'})
        fb.patch('cars_func/{}/power'.format(car_name),{'air':'off','sunroof':'off'})
        return ("모든 전원이 꺼집니다.")
    elif text.find("모두 켜줘") >=0:
        print("모든 전원이 켜집니다.")
        ps.led_on('liv',car_name)
        ps.led_on('bath',car_name)
        ps.led_on('kit',car_name)
        ps.led_on('outdoor',car_name)
        ps.air_on(car_name)
        ps.window_on(car_name)
        fb.patch('cars_func/{}/led'.format(car_name),{'liv':'on','bath':'on','kit':'on','outdoor':'on'})
        fb.patch('cars_func/{}/power'.format(car_name),{'air':'on','sunroof':'on'})
        return ("모든 전원이 켜집니다.")
    elif text.find("물 알려줘") >= 0:
        print("물 알려줘")
        result = ps.sensor_water(car_name) + ' 리터 남았습니다'
        return (result)
    else:
        return("정확한 명령을 말해주세요")
    
def extinguisher():
    print("소화기는 침대옆에 있습니다.사용법은 벽면에 붙어있으며, 앱을 통해서도 확인가능합니다.")
    return("소화기는 침대옆에 있습니다.사용법은 벽면에 붙어있으며, 앱을 통해서도 확인가능합니다.")

def chicken():
    print("근처 치킨집은 BHC,BBQ가 있습니다.어디로 알려드릴까요?")
    return ("근처 치킨집은 BHC,BBQ가 있습니다.어디로 알려드릴까요?")
def chicken_tel(text):
    if text.find("BBQ") >= 0 or text.find("비비큐") >= 0:
        print("BBQ는 010-2345-6789 입니다.")
        return ("BBQ는 010-2345-6789 입니다.")
    elif text.find("BHC") >=0 or text.find("비에이치씨") >= 0 or text.find("비에치씨") >= 0:
        print("BHC는 010-1234-5678 입니다.")
        return ("BHC는 010-1234-5678 입니다.")
    else:
        print("처음으로 돌아갑니다.")
        return ("처음으로 돌아갑니다.")
    
def temp_humidity():
    temp = ps.temperature('CaravanA')
    humi = ps.humidity('CaravanA')
    return ("현재온도는 {} 습도는 {} 입니다".format(temp,humi))

def main():
    #Example7 KWS+STT
    try:
        KWSID = ['기가지니', '지니야', '친구야', '자기야']
        while 1:
            recog=kws.test(KWSID[2])
            if recog == 200:
                print('KWS Dectected ...\n Start STT...')
                text = gv2t.getVoice2Text()
                print('Recognized Text: '+ text)
                
                if text.find("노래 틀어줘") >= 0 or text.find("노래 들려줘") >= 0:
                    py.main(text)
                elif text.find("소화기 위치") >=0 or text.find("소화기 어딨어") >=0:
                    tts.getText2VoiceStream(extinguisher(), "result_TTS.wav")
                    MS.play_file("result_TTS.wav")
                elif text.find("치킨집") >=0:
                    tts.getText2VoiceStream(chicken(), "result_TTS.wav")
                    MS.play_file("result_TTS.wav")
                    
                    text = gv2t.getVoice2Text()
                    print('Recognized Text: '+ text)
                    
                    if text.find("bbq") >= 0 or text.find("비비큐") >= 0:
                        text = "BBQ"
                    elif text.find("bhc") >=0 or text.find("비에이치씨") >= 0 or text.find("비에치씨") >= 0:
                        text = "BHC"
                    tts.getText2VoiceStream(chicken_tel(text),"result_TTS.wav")
                    MS.play_file("result_TTS.wav")
                elif text.find("켜줘") >= 0 or text.find("꺼") >= 0 or text.find("물 알려줘") >= 0 or text.find("SUNROOF")>=0 or text.find("sunroof")>=0:
                    tts.getText2VoiceStream(ledControl(text), "result_TTS.wav")
                    MS.play_file("result_TTS.wav")
                elif text.find("온습도 알려줘")>=0:
                    tts.getText2VoiceStream(temp_humidity(),"result_TTS.wav")
                    MS.play_file("result_TTS.wav")
                else:
                    tts.getText2VoiceStream(queryByText(text),"result_TTS.wav")
                    MS.play_file("result_TTS.wav")
                time.sleep(4)
            else:
                print('KWS Not Dectected')
    except KeyboardInterrupt:
        return -1

def sensor():
    try:
        while 1:
            car_name = fb.get('cars_func/car_name',None)
            print(car_name)
            if car_name=='CaravanA':
                led_list = fb.get('cars_func/{}'.format(car_name),'led')
                power_list = fb.get('cars_func/{}'.format(car_name),'power')
                for led_dict in led_list:
                    led = led_dict
                    if led_list[led_dict]=='on':
                        ps.led_on(led,car_name)
                    elif led_list[led_dict]=='off':
                        ps.led_off(led,car_name)
                if power_list['air']=='on':
                    ps.air_on(car_name)
                elif power_list['air']=='off':
                    ps.air_off(car_name)
                if power_list['sunroof']=='on':
                    ps.window_on(car_name)
                elif power_list['sunroof']=='off':
                    ps.window_off(car_name)
                fire_val = ps.sensor_fire(car_name)
                print('fire_val : ',fire_val)
                if fire_val < 850:
                    output_file = "testtts.wav"
                    tts.getText2VoiceStream("화재위험이 있어요!!소화기는 침대옆에 있습니다.", output_file)
                    MS.play_file(output_file)
                    fb.patch('cars_func/{}/power'.format(car_name),{'fire':'on'})
                else:
                    fb.patch('cars_func/{}/power'.format(car_name),{'fire':'off'})
                fb.patch('cars_func/{}'.format(car_name),{'water':ps.sensor_water(car_name),'temperature':ps.temperature(car_name),
                                                          'humidity':ps.humidity(car_name)})
                #print('water : {}, temp : {}, humidity : {}'.format(ps.sensor_water(car_name),ps.temperature(car_name),ps.humidity(car_name)))
                
            else:
                led_list = fb.get('cars_func/{}'.format(car_name),'led')
                if led_list['liv']=='on':
                    ps.led_on('liv',car_name)
                elif led_list['liv']=='off':
                    ps.led_off('liv',car_name)
            #time.sleep(4)
            
    except KeyboardInterrupt:
        return -1


def play_with_url(play_url):
    print(play_url)
    video = pafy.new(play_url)
    best = video.getbestaudio()
    playurl = best.url
    global play_flag
    play_flag = 0
    
    pya = pyaudio.PyAudio()
    stream = pya.open(format=pya.get_format_from_width(width=2),channels=1,rate=16000,
                      output=True)
    try:
        process = (ffmpeg
                   .input(playurl,err_detect='ignore_err',reconnect=1,reconnect_streamed=1,
                          reconnect_delay_max=5)
                   .output('pipe:',format='wav',audio_bitrate=16000,ab=64,ac=1,ar='16k')
                   .overwrite_output()
                   .run_async(pipe_stdout=True)
                   )
        while True:
            if play_flag == 0:
                in_bytes = process.stdout.read(4096)
                if not in_bytes:
                    break
                stream.write(in_bytes)
            else:
                break
    finally:
        stream.stop_stream()
        stream.close()

def youtube_search(options):
    try:
        youtube = build(YOUTUBE_API_SERVICE_NAME,YOUTUBE_API_VERSION, developerKey=DEVELOPER_KEY)
        
        parser = argparse.ArgumentParser()
        parser.add_argument('--q',help='Search term', default=options)
        parser.add_argument('--max-results',help='Max results', default=25)
        args = parser.parse_args()
        
        search_response = youtube.search().list(
            q=args.q,
            part='snippet',
            maxResults=args.max_results
        ).execute()
        
        videos=[]
        url=[]
        
        for search_result in search_response.get('items',[]):
            if search_result['id']['kind']=='youtube#video':
                videos.append('%s (%s)' % (search_result['snippet']['title'],search_result['id']['videoId']))
                url.append(search_result['id']['videoId'])
        print('url[0] : ',url[0])
        resultURL = "https://www.youtube.com/watch?v="+url[0]
        return resultURL
    except:
        print("Youtube Error")
        
        
if __name__ == '__main__':
    try:
        th1 = Thread(target=main)
        th2 = Thread(target=sensor)
        th2.start()
        th1.start()
    except KeyboardInterrupt:
        th2.kill()
        th1.kill()
        