import serial

ser = serial.Serial('/dev/ttyUSB0',9600)

def sensor_fire(car_name):
    req = '{}:fire_sensor\n'.format(car_name)
    ser.write(req.encode('utf-8'))
    while 1:
        temp = ser.readline()
        temp = str(temp)[2:-5]
        if temp == '{}:fire_sensor'.format(car_name):
            break
    result = ser.readline()
    result = str(result)[2:-5]
    result = int(result)
    return result
def sensor_water(car_name):
    req = '{}:water_sensor\n'.format(car_name)
    ser.write(req.encode('utf-8'))
    while 1:
        temp = ser.readline()
        temp = str(temp)[2:-5]
        if temp == '{}:water_sensor'.format(car_name):
            break
    result = ser.readline()
    result = str(result)[2:-5]
    return result
def led_on(pin,car_name):
    if pin == 'liv':
        req = '{}:led_liv/on\n'.format(car_name)
    elif pin =='bath':
        req = '{}:led_bath/on\n'.format(car_name)
    elif pin =='kit':
        req = '{}:led_kit/on\n'.format(car_name)
    elif pin =='outdoor':
        req = '{}:led_out/on\n'.format(car_name)
    ser.write(req.encode('utf-8'))
def led_off(pin,car_name):
    if pin == 'liv':
        req = '{}:led_liv/off\n'.format(car_name)
    elif pin =='bath':
        req = '{}:led_bath/off\n'.format(car_name)
    elif pin =='kit':
        req = '{}:led_kit/off\n'.format(car_name)
    elif pin =='outdoor':
        req = '{}:led_out/off\n'.format(car_name)
    ser.write(req.encode('utf-8'))
def air_on(car_name):
    req = '{}:power_air/on\n'.format(car_name)
    ser.write(req.encode('utf-8'))
def air_off(car_name):
    req = '{}:power_air/off\n'.format(car_name)
    ser.write(req.encode('utf-8'))
def window_on(car_name):
    req = '{}:power_window/on\n'.format(car_name)
    ser.write(req.encode('utf-8'))
def window_off(car_name):
    req = '{}:power_window/off\n'.format(car_name)
    ser.write(req.encode('utf-8'))
def temperature(car_name):
    req = '{}:temperature\n'.format(car_name)
    ser.write(req.encode('utf-8'))
    while 1:
        temp = ser.readline()
        temp = str(temp)[2:-5]
        if temp == '{}:temperature'.format(car_name):
            break
    result = ser.readline()
    result = str(result)[2:-5]
    return result
def humidity(car_name):
    req = '{}:humidity\n'.format(car_name)
    ser.write(req.encode('utf-8'))
    while 1:
        temp = ser.readline()
        temp = str(temp)[2:-5]
        if temp == '{}:humidity'.format(car_name):
            break
    result = ser.readline()
    result = str(result)[2:-5]
    return result