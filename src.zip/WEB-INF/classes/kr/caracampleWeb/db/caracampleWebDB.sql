drop table managers cascade constraint;

create table managers(
	managerID varchar2(20),
	managerPW varchar2(20) not null,
	managerName varchar2(20) not null,
	managerEmail varchar2(30),
	constraint manager_managerID_pk primary key(managerID)
);

select * from managers;

drop table cars cascade constraints;
drop table cars_func cascade constraints;
drop table customer cascade constraints;
drop table consult cascade constraints;
drop table review cascade constraints;
drop sequence customer_num_seq;
drop sequence con_num_seq;

create sequence customer_num_seq
increment by 1
start with 1
maxvalue 999;

create sequence con_num_seq
increment by 1
start with 1
maxvalue 999;

-- table --
create table cars(      
   car_name varchar2(20),
   pw varchar2(30) NOT NULL,
   constraint cars_carName_pk primary key(car_name)
);

insert into cars(car_name, pw)
values('CaravanA','1234');
insert into cars(car_name, pw)
values('CaravanB','1234');
insert into cars(car_name, pw)
values('CaravanC','1234');
insert into cars(car_name, pw)
values('CaravanD','1234');
insert into cars(car_name, pw)
values('CaravanE','1234');
insert into cars(car_name, pw)
values('CaravanF','1234');
insert into cars(car_name, pw)
values('CaravanG','1234');
insert into cars(car_name, pw)
values('CaravanH','1234');
insert into cars(car_name, pw)
values('CaravanI','1234');
insert into cars(car_name, pw)
values('CaravanAdmin','1234');



create table cars_func(
   car_name varchar2(20) references cars(car_name),
   led_liv varchar2(2) default '0',
   led_bath varchar2(2) default '0',
   led_kit varchar2(2) default '0',
   air_power varchar2(2) default '0',
   fire_power varchar2(2) default '0'
);
 
insert into cars_func(car_name)
values('CaravanA');
insert into cars_func(car_name)
values('CaravanB');
insert into cars_func(car_name)
values('CaravanC');
insert into cars_func(car_name)
values('CaravanD');
insert into cars_func(car_name)
values('CaravanE');
insert into cars_func(car_name)
values('CaravanF');
insert into cars_func(car_name)
values('CaravanG');
insert into cars_func(car_name)
values('CaravanH');
insert into cars_func(car_name)
values('CaravanI');


select * from cars_func;

create table customer(
   num number ,
   name varchar2(20) not null,
   tel varchar2(30) not null,
   car_name varchar2(20) references cars(car_name),
   male number(2) default 0,
   female number(2) default 0,
   check_in timestamp(0) default sysdate,
   check_out timestamp(0) default trunc(sysdate,'dd') +1+1/2,
   able varchar2(2) default '1',
   constraint customer_num_pk primary key(num)
);


select * from customer;

insert into customer(num,name,tel,car_name,female)
values(customer_num_seq.nextval,'오유정','01000000001','CaravanA',4);
insert into customer(num,name,tel,car_name,male,female)
values(customer_num_seq.nextval,'양기영','01000000002','CaravanB',3,2);
insert into customer(num,name,tel,car_name,male,female)
values(customer_num_seq.nextval,'신은정','01000000003','CaravanC',1,3);
insert into customer(num,name,tel,car_name,male,female)
values(customer_num_seq.nextval,'최광','01000000004','CaravanE',3,1);
insert into customer(num,name,tel,car_name,male,female)
values(customer_num_seq.nextval,'김재휘','01000000005','CaravanH',2,3);




create table consult (
   con_num number,
   num number references customer(num),
   cmt varchar2(100),
   time timestamp(0) default sysdate,
   complete varchar2(2) default '0',
   constraint consult_con_num_pk primary key(con_num)
);

insert into consult(con_num,num,cmt)
values(con_num_seq.nextval,1,'숯불 가져다주세요');
insert into consult(con_num,num,cmt)
values(con_num_seq.nextval,2,'이불 바꿔주세요');

select * from consult;

create table review(
   num number references customer(num),
   score number(2),
   cmt_review varchar2(1000),
   time timestamp(0) default sysdate
);

insert into review(num,score,cmt_review)
values(1,5,'너무 좋았어요');
insert into review(num,score,cmt_review)
values(2,3,'청결에 조금 더 신경써주셨으면 좋겠습니다.');

select * from review;



drop table managers cascade constraint;

create table managers(
   managerID varchar2(20),
   managerPW varchar2(20) not null,
   managerName varchar2(20) not null,
   managerEmail varchar2(30),
   constraint manager_managerID_pk primary key(managerID)
);

insert into managers(managerID, managerPW, managerName, managerEmail)
values('admin','1234','오유정','yujeong@naver.com');

select * from managers;

create or replace view month_view AS
select * from(
	select extract(month from check_in) as month,
	sum(male+female) as total
	from customer
	group by extract(month from check_in)
	order by extract(month from check_in)
);

select * from month_view;

